
import java.util.Scanner;

public class Programa2 {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        Scanner Leer2 = new Scanner(System.in);
        String  user [] = {"Daiana", "Facundo", "Osvaldo" , "Melina"};
        int pass[] = {1234, 4321, 1122 , 23344};
        boolean bandera=false;
            do {
                for (int j = 0; j < user.length; j++) {
                    System.out.println("Usuario");
                    String usuario = Leer.nextLine();
                        for (int k = 0; k < pass.length; k++) {
                            if (user[k].equals(usuario)){
                                System.out.println("Usuario: "+ user[k]);
                                System.out.println("Contraseña");
                                int contraseña = Leer.nextInt();
                                if (pass[k]== contraseña){
                                    System.out.println("Bienvenido");
                                    System.out.println("1) Cambiar Contraseña");
                                    System.out.println("2) Cerrar Sesion ");
                                    int op = Leer.nextInt();
                                    if(op == 1){
                                        System.out.println("Ingrese la nueva contraseña");
                                        int contra= Leer.nextInt();
                                        pass[k] = contra;
                                        System.out.println("Contraseña cambiada correctamente");
                                        break;
                                    }if(op == 2){
                                        System.out.println("Hasta pronto");
                                        bandera = true;
                                        break;
                                    }
                                }else{
                                    System.out.println("Contraseña incorrecta");
                                    System.out.println("intente nuevamente");
                                }
                            }
                        } break;
                }
            } while (bandera != true);








    }
}
