import java.util.Scanner;
import java.util.Vector;

public class Programa1 {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        String vector[] = new String[4];
        for (int i = 0; i < vector.length; i++) {
            System.out.println("Ingrese una frase celebré");
            vector[i] = Leer.nextLine();
        }

        for (int i = 0; i < vector.length; i++) {
            System.out.println(vector[i]);
        }
    }
}
