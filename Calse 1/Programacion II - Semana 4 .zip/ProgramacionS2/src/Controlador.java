import java.util.Scanner;

public class Controlador {

    public static void main(String[] args) {
       String a =Vista.entregarPersona();
       String b = Vista.entregarP();
       System.out.println(Vista.mostrarPersona(a));
       System.out.println(Vista.mostrarPersona(b));
    }
}
