
import java.util.Scanner;
public class Vista {

    public static String entregarPersona (){
        Scanner Leer = new Scanner(System.in);
        Persona p = new Persona();
        System.out.println("Ingrese su nombre");
        p.setNombre(Leer.nextLine());
        System.out.println("Ingrese su apellido");
        p.setApellido(Leer.nextLine());
        return p.toString();
    }

    public static String entregarP(){
        Scanner Leer = new Scanner(System.in);
        Ciudadano c = new Ciudadano();
        System.out.println("Ingrese su DNI");
        c.setDni(Leer.nextLong());
        System.out.println("Ingrese Su Provincia");
        c.setProvincia(Leer.next());
        return "Ciudadano: " + "Provincia=" + c.getProvincia() + ", DNI=" + c.getDni();
    }

    public static String mostrarPersona(String a){
        return a ;

    }




}
