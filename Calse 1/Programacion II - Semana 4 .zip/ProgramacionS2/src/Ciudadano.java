public class Ciudadano extends Persona{
    private String provincia;
    private long dni;

    public String getProvincia() {
        return provincia;
    }

    public void setProvincia(String provincia) {
        this.provincia = provincia;
    }

    public long getDni() {
        return dni;
    }

    public void setDni(long dni) {
        this.dni = dni;
    }

    @Override
    public String toString() {
        return "Ciudadano{" +
                "provincia='" + provincia + '\'' +
                ", dni=" + dni +
                '}';
    }
}
