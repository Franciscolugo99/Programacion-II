
import java.util.Scanner;

public class Vista {
    public static Cliente entregarCliente(){
        Scanner Leer = new Scanner(System.in);
        Cliente C= new Cliente();
        System.out.println("Ingrese su nombre");
        C.setNombre(Leer.nextLine());
        System.out.println("Ingrese su apellido");
        C.setApellido(Leer.nextLine());
        System.out.println("Ingrese su edad");
        C.setEdad(Leer.nextInt());
        System.out.println("Seleccione la opción que desea abonar");
        System.out.println("1) Semana Completa");
        System.out.println("2) Media Semana");
        int op = Leer.nextInt();
        if (op == 1) {
            C.setAbonadoFull("Semana Completa");
        }
        if (op==2){
            C.setAbonadoMediotiempo("Media Semana");
        }
        return C;
    }

    public static Cliente mostrar(Cliente a){
        System.out.println(a);
        return a;
    }

}
