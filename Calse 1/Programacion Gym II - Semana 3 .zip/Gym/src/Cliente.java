public class Cliente implements Comparable <Cliente>{
    private String nombre;
    private String apellido;
    private int edad;
    private String AbonadoFull;
    private String AbonadoMediotiempo;



    public String getNombre() {
        return this.nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return this.apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getEdad() {
        return this.edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public String getAbonadoFull() {
        return this.AbonadoFull;
    }

    public void setAbonadoFull(String abonadoFull) {
        AbonadoFull = abonadoFull;
    }

    public String getAbonadoMediotiempo() {
        return this.AbonadoMediotiempo;
    }

    public void setAbonadoMediotiempo(String abonadoMediotiempo) {
        AbonadoMediotiempo = abonadoMediotiempo;
    }

    @Override
    public String toString() {
        return "Cliente{" +
                "nombre='" + nombre + '\'' +
                ", apellido='" + apellido + '\'' +
                ", edad=" + edad +
                ", AbonadoFull='" + AbonadoFull + '\'' +
                ", AbonadoMediotiempo='" + AbonadoMediotiempo + '\'' +
                '}';
    }

    @Override
    public int compareTo(Cliente p) {
        return getEdad() - getEdad();
    }
}
