import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;

public class Controlador {
    public static void main(String[] args) {

        Cliente miCliente = Vista.entregarCliente();
        Cliente miCliente2 = Vista.entregarCliente();
        Cliente miCliente3 = Vista.entregarCliente();
        ArrayList <Cliente> cliente = new ArrayList<>();
        cliente.add(miCliente);
        cliente.add(miCliente2);
        cliente.add(miCliente3);

        cliente.sort(Cliente::compareTo);


        System.out.println(cliente);
    }



}
