//Dado el usuario Enzo y la contraseña 4321, escribir un programa que indique cuando hay un error
// en el usuario o en la contraseña o en ambos.


import java.util.Scanner;

public class programa7 {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        String User = "Enzo", newUser;
        int pass = 4321, newPass;
        boolean bandera = false;
        System.out.println("Ingrese Su nombre de Usuario:");
        newUser = Leer.nextLine();
        System.out.println("--------------");
        System.out.println("Ingrese Su Contraseña:");
        newPass = Leer.nextInt();
        do {
            if (newUser == User || newPass == pass) {
                System.out.println("Bienvenido Enzo");
                bandera = true;
            } else {
                System.out.println("Usuario o contraseña Incorrecta");
                System.out.println("1) Intente de nuevo");
                System.out.println("2) Salir");
                System.out.println(pass + " " + User);
                int opc = Leer.nextInt();
                if (opc == 1) {
                    System.out.println("Ingrese Su nombre de Usuario:");
                    newUser = Leer.next();
                    System.out.println("--------------");
                    System.out.println("Ingrese Su Contraseña:");
                    newPass = Leer.nextInt();
                    bandera = false;
                }
                if (opc == 2) {
                    bandera = true;
                }
            }
        } while (bandera != true);
    }
}
