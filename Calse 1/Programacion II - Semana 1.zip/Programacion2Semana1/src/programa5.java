//Escribir un programa similar al anterior, pero que no imprima los múltiplos de un número
// también ingresado por el usuario. Por ejemplo, si se ingresaron los números 22, 18 y 3
// el programa debe imprimir 19 20 22.



import java.util.Scanner;

public class programa5 {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        System.out.println("Ingrese un numero");
        int num1 = Leer.nextInt();
        System.out.println("Ingrese otro numero");
        int num2 = Leer.nextInt();
        System.out.println("Ingrese otro numero que elimine los multiplos del mismo");
        int num3 = Leer.nextInt();
        int may=num1 , men=num2;
/*        if (num1 > num2 && num1 >num3) {
            System.out.println("1");
            may = num1;
            men = num3;
        } else {
            if (num2 > num1 && num2 > num3) {
                System.out.println("2");
                may = num2;
                men = num3;
            } else {
                if (num3 > num2 && num3 > num1) {
                    System.out.println("3");
                    may = num3;
                    men = num1;
                }
            }
        }
        System.out.println("---------------------------------");
        System.out.println("EL numero mayor es = " + may);
        System.out.println("El numero menor es = " + men);
        System.out.println("---------------------------------");*/
        if (may < men){
            for (int i = may; i < men + 1; i++) {
                if (i % num3 != 0){
                    System.out.println("N="+ i);
                }

            }
        } else {
            for (int i = men; i < may +1; i++) {
                if (i % num3 != 0){
                    System.out.println("N="+ i);
                }
            }
        }


    }
}