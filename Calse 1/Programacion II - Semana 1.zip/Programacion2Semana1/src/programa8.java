//Modifique el programa anterior (pero no lo deseche pues debe presentarlo), de manera
// que el usuario pueda modificar la contraseña una vez que se haya “logueado”
// o identificado correctamente.


import java.util.Scanner;

public class programa8 {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        String User = "Enzo", newUser;
        int pass = 4321, newPass;
        boolean bandera = false;
        System.out.println("Ingrese Su nombre de Usuario:");
        newUser = Leer.nextLine();
        System.out.println("--------------");
        System.out.println("Ingrese Su Contraseña:");
        newPass = Leer.nextInt();
        do {
            if (newUser == User || newPass == pass) {
                System.out.println("Bienvenido Enzo");
                System.out.println("1)Modificar Contraseña");
                System.out.println("2)Salir");
                int op = Leer.nextInt();
                if (op == 1) {
                    System.out.println("Ingrese la nueva contraseña: ");
                    pass = Leer.nextInt();
                    System.out.println("Su nueva contraseña es: " + pass);
                    bandera = true;
                }
                if (op == 2) {
                    bandera = true;
                }
            } else if (newUser != User && newPass != pass ) {
                System.out.println("Usuario o contraseña Incorrecta");
                System.out.println("1) Intente de nuevo");
                System.out.println("2) Salir");
                System.out.println(pass + " " + User);
                int opc = Leer.nextInt();
                if (opc == 1) {
                    System.out.println("Ingrese Su nombre de Usuario:");
                    newUser = Leer.next();

                    System.out.println("--------------");
                    System.out.println("Ingrese Su Contraseña:");
                    newPass = Leer.nextInt();
                    bandera = false;
                }
                if (opc == 2) {
                    bandera = false;
                }
            }
        } while (bandera == true);
    }
}
