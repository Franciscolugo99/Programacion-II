
//Escribir un programa similar al anterior, pero que no imprima los múltiplos de 5.
// Por ejemplo,si se ingresaron los números 22 y 18, el programa debe imprimir 18 19 21 22.


import java.util.Scanner;

public class programa4 {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        System.out.println("Ingrese un numero");
        int num1 = Leer.nextInt();
        System.out.println("Ingrese otro numero");
        int num2 = Leer.nextInt();
        if (num1 < num2){
            for (int i = num1; i < num2 + 1; i++) {
                if (i % 5 != 0){
                    System.out.println("N="+ i);
                }

            }
        } else {
            for (int i = num2; i < num1 +1; i++) {
                if (i % 5 != 0){
                    System.out.println("N="+ i);
                }
            }
        }




    }
}
