import java.util.Scanner;

//        Escribir un programa que, modificando el anterior,
//        imprima los números enteros entre los dos ingresados siempre de menor a mayor,
//        independientemente del orden en que los ingresó el usuario. Por ejemplo,
//        si se ingresaron los números 20 y 17, el programa debe imprimir 17 18 19 20.
public class programa3 {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        System.out.println("Ingrese un numero");
        int num1 = Leer.nextInt();
        System.out.println("Ingrese otro numero");
        int num2 = Leer.nextInt();
        if (num1 < num2){
            for (int i = num1; i < num2 + 1; i++) {
                System.out.println("N°="+ i);
             }
        } else {
            for (int i = num2; i < num1 +1; i++) {
                System.out.println("N="+ i);
            }
        }


    }
}
