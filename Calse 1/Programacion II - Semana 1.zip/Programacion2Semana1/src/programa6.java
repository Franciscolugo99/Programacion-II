//Modifique el programa anterior (conservándolo) para que le advierta al usuario si el tercer número
// ingresado es mayor o igual a la diferencia entre los dos primeros.
// Por ejemplo si el usuario ingresa 22, 18 y 6 debe advertir al usuario que 6 es un número no permitido
// porque es mayor a 22 menos 18.


import java.util.Scanner;

public class programa6 {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        System.out.println("Ingrese un numero");
        int num1 = Leer.nextInt();
        System.out.println("Ingrese otro numero");
        int num2 = Leer.nextInt();
        System.out.println("Ingrese otro numero que elimine los multiplos del mismo");
        int num3 = Leer.nextInt();
        int may=0 , men=0 , mul=num3;
        if (num1 > num2 ) {
            System.out.println("1");
            may = num1;
            men = num2;
        } else {
            if (num2 > num1 ) {
                System.out.println("2");
                may = num2;
                men = num1;
            }
        }
        int res = may-men;
        if (mul > res){
            System.out.println("el numero 3 ingresado es mayor al resto de los 2 primeros");
        } else {
            if (may < men){
                for (int i = may; i < men + 1; i++) {
                    if (i % mul != 0){
                        System.out.println("N="+ i);
                    }

                }
            } else {
                for (int i = men; i < may +1; i++) {
                    if (i % mul != 0){
                        System.out.println("N="+ i);
                    }
                }
            }

        }
        System.out.println("---------------------------------");
        System.out.println("EL numero mayor es = " + may);
        System.out.println("El numero menor es = " + men);
        System.out.println("el resto de los 2 numeros es = " + res);
        System.out.println("---------------------------------");



    }
}
