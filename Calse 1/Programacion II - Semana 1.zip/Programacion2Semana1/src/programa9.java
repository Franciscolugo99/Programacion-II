import java.util.Scanner;

public class programa9 {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        int con=0, contador2 =0 ,voc;
        System.out.println("Ingrese una frase");
        String Frase = Leer.nextLine();
        String frase= Frase.toLowerCase();
        System.out.println(frase);
        for (int i = 0; i < frase.length() ; i++) {
            con++;
        }
        for (int i = 0; i < frase.length(); i++) {
            if (frase.charAt(i) == 'a' || frase.charAt(i) =='o' ||frase.charAt(i) == 'u' ||
                    frase.charAt(i) == 'e' ||frase.charAt(i) =='i') {
                contador2++;
            }
        }
        System.out.println("Hay (" +contador2 +") vocales en la frase ingresada");
    }
}
