import java.util.Scanner;
//        Escribir un programa que reciba dos números
//        por consola e imprima todos los números enteros entre esos dos números.
public class programa2 {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in);
        System.out.println("Ingrese un numero");
        int num1 = Leer.nextInt();
        System.out.println("Ingrese otro numero");
        int num2 = Leer.nextInt();
        for (int i = num1; i < num2 ; i++) {
            System.out.println("N°="+ i);
        }

    }
}
