import java.util.Scanner;

public class programa1 {
    public static void main(String[] args) {
        Scanner Leer = new Scanner(System.in) ;
        System.out.println("Igrese un numero");
        int num1 = Leer.nextInt();
        System.out.println("Igrese otro numero");
        int num2 = Leer.nextInt();
        int num3 = num1+num2;
        System.out.println("La suma de los 2 numeros ingresados es: " + num3);
    }
}
