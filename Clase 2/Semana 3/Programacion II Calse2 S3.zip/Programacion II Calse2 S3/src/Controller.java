import java.util.ArrayList;
import java.util.Scanner;

public class Controller {
    public static void main(String[] args) {
        Contact C = new Contact();
        ContactBook CB = new ContactBook();
        Scanner Leer = new Scanner(System.in);
        System.out.println("Menu");
        C = new Contact("EnzoVonkunoschy", "enzo@gmail.com", "345345654", false);
        ArrayList<Object> listContactBook = new ArrayList<>();
        listContactBook.add(C);
        boolean badera = false;
        do {
            System.out.println("Desea agregar otro contacto");
            System.out.println("1) Si");
            System.out.println("2) No");
            int opc2 = Leer.nextInt();
            if (opc2 == 1) {
                listContactBook.add(CB.addContact());
            }
            if (opc2==2){
                badera = true;
            }
        }while (badera == false);

        for (int i = 0; i < listContactBook.size(); i++) {
            System.out.print("|"+listContactBook.get(i));
        }




    }
}
