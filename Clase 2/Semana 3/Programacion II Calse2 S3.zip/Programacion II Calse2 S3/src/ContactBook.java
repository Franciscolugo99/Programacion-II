import java.util.ArrayList;
import java.util.Scanner;

public class ContactBook extends Contact {
    private String name;

    public ContactBook() {
        super();
    }

    public ContactBook(String name, String email, String movil, boolean topList) {
        super(name, email, movil, topList);
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Object addContact(){
        Scanner Leer = new Scanner(System.in);
        Contact C2 = new Contact();
        ContactBook CB2 = new ContactBook();
        System.out.println("Ingrese el nombre de contacto");
        String name = Leer.next();
        C2.setName(name);
        System.out.println("Ingrese el email del contacto");
        String email = Leer.next();
        System.out.println("Ingrese el movil del contacto");
        String movil = Leer.next();
        C2.setEmail(email);
        C2.setMovil(movil);
        C2.setTopList(true);
        return C2;
    }

    public void delContact (String c){
        Contact Con = new Contact();
        c.equals(Con);

    }
    public boolean isTheContact (Contact c){
        return true;
    }

    @Override
    public String toString() {
        return "ContactBook{" +
                "name='" + name + '\'' +
                '}';
    }
}
