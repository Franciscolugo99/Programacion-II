public class Main {
    public static void main(String[] args) {
        Grado Aplicacion = new Grado("Franco", 12);
        System.out.println(Aplicacion);

        Escuela miAplicacion = (Escuela) Aplicacion;
        System.out.println(miAplicacion);

        Escuela obj = new Escuela();
        System.out.println(obj);
        Grado miobj = (Grado) obj;
        System.out.println(miobj);

    }
}
