public class Grado extends Escuela {
    private String nom;
    private int cantAlumno;

    public Grado() {
    }

    public Grado(String nom, int cantAlumno) {
        this.nom = nom;
        this.cantAlumno = cantAlumno;
    }

    public String getNom() {
        return this.nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public int getCantAlumno() {
        return this.cantAlumno;
    }

    public void setCantAlumno(int cantAlumno) {
        this.cantAlumno = cantAlumno;
    }

    @Override
    public String toString() {
        return "Grado{" +
                "nom='" + nom + '\'' +
                ", cantAlumno=" + cantAlumno +
                '}';
    }
}
